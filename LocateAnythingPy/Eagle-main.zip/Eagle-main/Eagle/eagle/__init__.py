from .model import EagleLlamaForCausalLM
