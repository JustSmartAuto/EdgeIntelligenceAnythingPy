# Copyright 2026 NVIDIA CORPORATION & AFFILIATES
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0
#
# This file is adopted from the XTuner project
# (https://github.com/InternLM/xtuner), licensed under the Apache License 2.0.
#
# Modifications © 2026 NVIDIA CORPORATION & AFFILIATES, licensed under
# the Apache License, Version 2.0.
#
# Copyright (c) OpenMMLab. All rights reserved.
import math

import torch.distributed as dist

from .comm import (all_to_all, gather_forward_split_backward,
                   split_forward_gather_backward)
from .globals import get_pg_manager


def repeat_kv_for_ulysses(states, query_heads):
    """Expand grouped-query KV heads to query-head order before all-to-all."""
    batch, sequence, kv_heads, head_dim = states.shape
    if query_heads % kv_heads != 0:
        raise ValueError(
            f'Query heads ({query_heads}) must be a multiple of KV heads ({kv_heads}).'
        )
    repeats = query_heads // kv_heads
    return (
        states[:, :, :, None, :]
        .expand(batch, sequence, kv_heads, repeats, head_dim)
        .reshape(batch, sequence, query_heads, head_dim)
        .contiguous()
    )


def pre_process_for_sequence_parallel_attn(query_states,
                                           key_states,
                                           value_states,
                                           scatter_dim=2,
                                           gather_dim=1):
    b, s_div_sp, h, d = query_states.shape
    sp = get_pg_manager().ulysses_sequence_parallel_world_size

    if h % sp != 0:
        raise ValueError(
            f'Query heads ({h}) must be divisible by the Ulysses size ({sp}).'
        )

    # Ulysses scatters the head dimension. GQA/MQA checkpoints often have
    # fewer KV heads than SP ranks (for example Qwen3 2B has 16 Q heads but
    # only 8 KV heads). Expand KV heads to the query-head count before the
    # all-to-all so every rank receives an equal, valid KV shard. This keeps
    # the per-rank KV activation size bounded because the sequence dimension
    # was already divided by SP.
    kv_heads = key_states.shape[2]
    if value_states.shape[2] != kv_heads:
        raise ValueError('Key and value tensors must have the same number of heads.')
    if kv_heads != h:
        if h % kv_heads != 0:
            raise ValueError(
                f'Query heads ({h}) must be a multiple of KV heads ({kv_heads}) for GQA expansion.'
            )
        key_states = repeat_kv_for_ulysses(key_states, h)
        value_states = repeat_kv_for_ulysses(value_states, h)

    # if not is_inner_sequence_parallel_initialized():
    #     insp = sp // math.gcd(h, sp)
    #     init_inner_sequence_parallel(insp)
    # else:
    #     insp = get_inner_sequence_parallel_world_size()

    # def pre_process_for_inner_sp(q, k, v):
    #     if scatter_dim != 2 and gather_dim != 1:
    #         raise NotImplementedError(
    #             'Currently only `scatter_dim == 2` and `gather_dim == 1` '
    #             f'is supported. But got scatter_dim = {scatter_dim} and '
    #             f'gather_dim = {gather_dim}.')

    #     # (b, s_div_sp, h, d) ->
    #     # (b, s_div_sp, sp/insp, h*insp/sp, insp, d/insp) ->
    #     # (b, s_div_sp, sp/insp, insp, h*insp/sp, d/insp) ->
    #     # (b, s_div_sp, insp*h, d/insp)
    #     q = q.view(b, s_div_sp, sp // insp, h * insp // sp, insp,
    #                d // insp).transpose(3, 4).flatten(2, 4)
    #     k = k.view(b, s_div_sp, sp // insp, h * insp // sp, insp,
    #                d // insp).transpose(3, 4).flatten(2, 4)
    #     v = v.view(b, s_div_sp, sp // insp, h * insp // sp, insp,
    #                d // insp).transpose(3, 4).flatten(2, 4)

    #     return q, k, v

    # def post_process_for_inner_sp(q, k, v):
    #     # (b, s, insp*h/sp, d/insp) -> (b, s, insp*h/sp, d)
    #     q = gather_forward_split_backward(q, -1,
    #                                       get_inner_sequence_parallel_group())
    #     k = gather_forward_split_backward(k, -1,
    #                                       get_inner_sequence_parallel_group())
    #     v = gather_forward_split_backward(v, -1,
    #                                       get_inner_sequence_parallel_group())

    #     return q, k, v

    # assert (h * insp) % sp == 0, \
    #     ('The number of attention heads should be divisible by '
    #      '(sequence_parallel_world_size // sequence_parallel_inner_world_size)'
    #      f'. But got n_head = {h}, sequence_parallel_world_size = '
    #      f'{sp} and sequence_parallel_inner_world_size = {insp}.')

    # if insp > 1:
    #     query_states, key_states, value_states = pre_process_for_inner_sp(
    #         query_states, key_states, value_states)

    # (b, s_div_sp, insp*h, d/insp) -> (b, s, insp*h/sp, d/insp)
    sequence_parallel_group = get_pg_manager().ulysses_sequence_parallel_group
    query_states = all_to_all(
        query_states,
        sequence_parallel_group,
        scatter_dim=scatter_dim,
        gather_dim=gather_dim)
    key_states = all_to_all(
        key_states,
        sequence_parallel_group,
        scatter_dim=scatter_dim,
        gather_dim=gather_dim)
    value_states = all_to_all(
        value_states,
        sequence_parallel_group,
        scatter_dim=scatter_dim,
        gather_dim=gather_dim)

    # if insp > 1:
    #     query_states, key_states, value_states = post_process_for_inner_sp(
    #         query_states, key_states, value_states)

    return query_states, key_states, value_states


def post_process_for_sequence_parallel_attn(attn_output,
                                            scatter_dim=1,
                                            gather_dim=2):
    sp = get_pg_manager().ulysses_sequence_parallel_world_size
    # insp = get_inner_sequence_parallel_world_size()
    b, s, h_mul_insp_div_sp, d = attn_output.shape
    h = h_mul_insp_div_sp * sp
    s_div_sp = s // sp

    # if insp > 1:
    #     # (b, s, insp*h/sp, d) -> (b, s, insp*h/sp, d/insp)
    #     attn_output = split_forward_gather_backward(
    #         attn_output, -1, get_inner_sequence_parallel_group())

    # (b, s, insp*h/sp, d/insp) -> (b, s_div_sp, insp*h, d/insp)
    sequence_parallel_group = get_pg_manager().ulysses_sequence_parallel_group
    output = all_to_all(
        attn_output,
        sequence_parallel_group,
        scatter_dim=scatter_dim,
        gather_dim=gather_dim)

    # if insp > 1:
    #     # (b, s_div_sp, insp*h, d/insp) ->
    #     # (b, s_div_sp, sp/insp, insp, h*insp/sp, d/insp) ->
    #     # (b, s_div_sp, sp/insp, h*insp/sp, insp, d/insp) ->
    #     # (b, s_div_sp, h, d)
    #     output = output.view(b, s_div_sp, sp // insp, insp, h * insp // sp,
    #                          d // insp).transpose(3, 4).reshape(
    #                              b, s_div_sp, h, d)

    return output


def sequence_parallel_wrapper(local_attn):

    def sequence_parallel_attn(query_states, key_states, value_states, *args,
                               **kwargs):
        training = kwargs.pop('training', True)
        enable_sequence_parallel = (
            dist.is_initialized() and get_pg_manager().sequence_parallel_world_size > 1
            and training)
        if enable_sequence_parallel:
            query_states, key_states, value_states = \
                pre_process_for_sequence_parallel_attn(
                    query_states, key_states, value_states,
                    scatter_dim=kwargs.pop('scatter_dim', 2),
                    gather_dim=kwargs.pop('gather_dim', 1))

        out = local_attn(query_states, key_states, value_states, *args,
                         **kwargs)

        if enable_sequence_parallel:
            out = post_process_for_sequence_parallel_attn(out).contiguous()

        return out

    return sequence_parallel_attn
